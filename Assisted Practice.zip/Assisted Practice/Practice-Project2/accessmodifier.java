
public class accessmodifier {

	
	
	
	
	
	//package co.simplilearn.demo;

//import co.simplilearn.demo.VariableDemo;

//public class VariableDemo {

			
			public void methodPublic() {
				System.out.println("This is public method");
			}
			
			private void methodPrivate() {
				System.out.println("This is private method");
			}
			
			void methodDefault() {
				System.out.println("This is default method");
			}
			
			protected void methodProtected() {
				System.out.println("This is protected method");
			}
			
			//same class able to aceess all types of modifiers
			public static void main(String [] args) {
				
				accessmodifier obj= new  accessmodifier();
				
				obj.methodDefault();
				obj.methodPrivate();
				obj.methodProtected();
				obj.methodPublic();
				
			
			}
		}


